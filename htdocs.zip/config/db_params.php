<?php

return array(
    'host' => 'localhost',
    'dbname' => 'magazine',
    'user' => 'root',
    'password' => '',            
);